import{s as ve,z as ee,m as be,A as $e,a as y,d as x,j as u,h as d,e as p,c as $,g as C,i as f,n as k,t as L,b as M,f as T,k as E,D as I,E as H}from"../chunks/scheduler.z1v5p5l_.js";import{S as ge,i as _e,c as m,b as v,m as b,t as g,a as _,d as w}from"../chunks/index.wUxZk5jp.js";import{g as we,a as fe}from"../chunks/spread.rEx3vLA9.js";import{M as ye}from"../chunks/mdsvex-components.Iy1ySU_z.js";import{p as xe,C as je,a as j,r as S}from"../chunks/ClassTable.zW_ZYmqo.js";import"../chunks/singletons.RTX2iUiw.js";function Ce(c){let e,i='<figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-1oufy6g"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function ke(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Le(c){let e,i='<figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-ejmz26"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 card-compact shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Me(c){let e,i=`<div class="$$card $$card-compact w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Te(c){let e,i=`<figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!
      <div class="badge badge-secondary">NEW</div></h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><div class="badge badge-outline">Fashion</div> <div class="badge badge-outline">Products</div></div></div>`;return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-1u8hxdu"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Ee(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">
      Shoes!
      <div class="$$badge $$badge-secondary">NEW</div>
    </h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <div class="$$badge $$badge-outline">Fashion</div> 
      <div class="$$badge $$badge-outline">Products</div>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Ie(c){let e,i='<div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p></div> <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-19okvep"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function He(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
  </div>
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Se(c){let e,i='<figure class="px-10 pt-10"><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" class="rounded-xl"/></figure> <div class="card-body items-center text-center"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-npb27v"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Ne(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <figure class="px-10 pt-10">
    <img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" class="rounded-xl" />
  </figure>
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function De(c){let e,i='<figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes"/></figure> <div class="card-body"><h2 class="card-title">Shoes!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-1czsuuv"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl image-full")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Pe(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl image-full">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Shoes!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Be(c){let e,i='<div class="card-body"><h2 class="card-title">Card title!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Buy Now</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-1j6hqpx"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Re(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Buy Now</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Ve(c){let e,i='<div class="card-body"><h2 class="card-title">Card title!</h2> <p>If a dog chews shoes whose shoes does he choose?</p> <div class="justify-end card-actions"><button class="btn">Buy Now</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-xb5ud6"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-primary text-primary-content")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Ae(c){let e,i=`<div class="$$card w-96 bg-primary text-primary-content">
  <div class="$$card-body">
    <h2 class="$$card-title">Card title!</h2>
    <p>If a dog chews shoes whose shoes does he choose?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn">Buy Now</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function We(c){let e,i='<div class="card-body items-center text-center"><h2 class="card-title">Cookies!</h2> <p>We are using cookies for no reason.</p> <div class="justify-end card-actions"><button class="btn btn-primary">Accept</button> <button class="btn btn-ghost">Deny</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-1i3w544"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-neutral text-neutral-content")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function qe(c){let e,i=`<div class="$$card w-96 bg-neutral text-neutral-content">
  <div class="$$card-body items-center text-center">
    <h2 class="$$card-title">Cookies!</h2>
    <p>We are using cookies for no reason.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Accept</button>
      <button class="$$btn $$btn-ghost">Deny</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function ze(c){let e,i='<div class="card-body"><div class="justify-end card-actions"><button class="btn btn-square btn-sm"><svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button></div> <p>We are using cookies for no reason.</p></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-1jhynqq"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Fe(c){let e,i=`<div class="$$card w-96 bg-base-100 shadow-xl">
  <div class="$$card-body">
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-square $$btn-sm">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
    </div>
    <p>We are using cookies for no reason.</p>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Je(c){let e,i='<figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="car!"/></figure> <div class="card-body"><h2 class="card-title">Life hack</h2> <p>How to park your car at your garage?</p> <div class="justify-end card-actions"><button class="btn btn-primary">Learn now!</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-11sivfk"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card w-96 glass")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Ge(c){let e,i=`<div class="$$card w-96 glass">
  <figure><img src="/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="car!"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">Life hack</h2>
    <p>How to park your car at your garage?</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Learn now!</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Ke(c){let e,i='<figure><img src="/images/stock/photo-1635805737707-575885ab0820.jpg" alt="Movie"/></figure> <div class="card-body"><h2 class="card-title">New movie is released!</h2> <p>Click the button to watch on Jetflix app.</p> <div class="justify-end card-actions"><button class="btn btn-primary">Watch</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-fbr2cn"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card card-side bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Oe(c){let e,i=`<div class="$$card $$card-side bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1635805737707-575885ab0820.jpg" alt="Movie"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New movie is released!</h2>
    <p>Click the button to watch on Jetflix app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Watch</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Qe(c){let e,i='<figure><img src="/images/stock/photo-1494232410401-ad00d5433cfa.jpg" alt="Album"/></figure> <div class="card-body"><h2 class="card-title">New album is released!</h2> <p>Click the button to listen on Spotiwhy app.</p> <div class="justify-end card-actions"><button class="btn btn-primary">Listen</button></div></div>';return{c(){e=p("div"),e.innerHTML=i,this.h()},l(t){e=$(t,"DIV",{class:!0,"data-svelte-h":!0}),C(e)!=="svelte-14o4x66"&&(e.innerHTML=i),this.h()},h(){f(e,"class","card lg:card-side bg-base-100 shadow-xl")},m(t,o){u(t,e,o)},p:k,d(t){t&&d(e)}}}function Ue(c){let e,i=`<div class="$$card lg:$$card-side bg-base-100 shadow-xl">
  <figure><img src="/images/stock/photo-1494232410401-ad00d5433cfa.jpg" alt="Album"/></figure>
  <div class="$$card-body">
    <h2 class="$$card-title">New album is released!</h2>
    <p>Click the button to listen on Spotiwhy app.</p>
    <div class="$$card-actions justify-end">
      <button class="$$btn $$btn-primary">Listen</button>
    </div>
  </div>
</div>`,t,o,n,h;return{c(){e=p("pre"),t=L(i),this.h()},l(s){e=$(s,"PRE",{slot:!0});var l=M(e);t=T(l,i),l.forEach(d),this.h()},h(){f(e,"slot","html")},m(s,l){u(s,e,l),E(e,t),n||(h=I(o=S.call(null,e,{to:c[0]})),n=!0)},p(s,l){o&&H(o.update)&&l&1&&o.update.call(null,{to:s[0]})},d(s){s&&d(e),n=!1,h()}}}function Xe(c){let e,i,t,o,n,h,s,l,N,F,D,J,P,G,B,K,R,O,V,Q,A,U,W,X,q,Y,z,Z;return e=new je({props:{data:[{type:"component",class:"card",desc:"Container element"},{type:"component",class:"card-title",desc:"Title of card"},{type:"component",class:"card-body",desc:"Container for content"},{type:"component",class:"card-actions",desc:"Container for buttons"},{type:"modifier",class:"card-bordered",desc:"Adds border to <card>"},{type:"modifier",class:"image-full",desc:"The image in <figure> element will be the background"},{type:"responsive",class:"card-normal",desc:"Applies default paddings"},{type:"responsive",class:"card-compact",desc:"Applies smaller padding"},{type:"responsive",class:"card-side",desc:"The image in <figure> will be on to the side"}]}}),t=new j({props:{title:"Card",$$slots:{html:[ke],default:[Ce]},$$scope:{ctx:c}}}),n=new j({props:{title:"Compact card (less padding for `card-body`)",$$slots:{html:[Me],default:[Le]},$$scope:{ctx:c}}}),s=new j({props:{title:"Card with badge",$$slots:{html:[Ee],default:[Te]},$$scope:{ctx:c}}}),N=new j({props:{title:"Card with bottom image",$$slots:{html:[He],default:[Ie]},$$scope:{ctx:c}}}),D=new j({props:{title:"Card with centered content and paddings",$$slots:{html:[Ne],default:[Se]},$$scope:{ctx:c}}}),P=new j({props:{title:"Card with image overlay",$$slots:{html:[Pe],default:[De]},$$scope:{ctx:c}}}),B=new j({props:{title:"Card with no image",$$slots:{html:[Re],default:[Be]},$$scope:{ctx:c}}}),R=new j({props:{title:"Card with custom color",$$slots:{html:[Ae],default:[Ve]},$$scope:{ctx:c}}}),V=new j({props:{title:"Centered card with neutral color",$$slots:{html:[qe],default:[We]},$$scope:{ctx:c}}}),A=new j({props:{title:"Card with action on top",$$slots:{html:[Fe],default:[ze]},$$scope:{ctx:c}}}),W=new j({props:{title:"Card glass",bg:"/images/stock/photo-1481026469463-66327c86e544.jpg",$$slots:{html:[Ge],default:[Je]},$$scope:{ctx:c}}}),q=new j({props:{title:"Card with image on side",$$slots:{html:[Oe],default:[Ke]},$$scope:{ctx:c}}}),z=new j({props:{title:"Responsive card (vertical on small screen, horizontal on large screen)",$$slots:{html:[Ue],default:[Qe]},$$scope:{ctx:c}}}),{c(){m(e.$$.fragment),i=y(),m(t.$$.fragment),o=y(),m(n.$$.fragment),h=y(),m(s.$$.fragment),l=y(),m(N.$$.fragment),F=y(),m(D.$$.fragment),J=y(),m(P.$$.fragment),G=y(),m(B.$$.fragment),K=y(),m(R.$$.fragment),O=y(),m(V.$$.fragment),Q=y(),m(A.$$.fragment),U=y(),m(W.$$.fragment),X=y(),m(q.$$.fragment),Y=y(),m(z.$$.fragment)},l(a){v(e.$$.fragment,a),i=x(a),v(t.$$.fragment,a),o=x(a),v(n.$$.fragment,a),h=x(a),v(s.$$.fragment,a),l=x(a),v(N.$$.fragment,a),F=x(a),v(D.$$.fragment,a),J=x(a),v(P.$$.fragment,a),G=x(a),v(B.$$.fragment,a),K=x(a),v(R.$$.fragment,a),O=x(a),v(V.$$.fragment,a),Q=x(a),v(A.$$.fragment,a),U=x(a),v(W.$$.fragment,a),X=x(a),v(q.$$.fragment,a),Y=x(a),v(z.$$.fragment,a)},m(a,r){b(e,a,r),u(a,i,r),b(t,a,r),u(a,o,r),b(n,a,r),u(a,h,r),b(s,a,r),u(a,l,r),b(N,a,r),u(a,F,r),b(D,a,r),u(a,J,r),b(P,a,r),u(a,G,r),b(B,a,r),u(a,K,r),b(R,a,r),u(a,O,r),b(V,a,r),u(a,Q,r),b(A,a,r),u(a,U,r),b(W,a,r),u(a,X,r),b(q,a,r),u(a,Y,r),b(z,a,r),Z=!0},p(a,r){const te={};r&5&&(te.$$scope={dirty:r,ctx:a}),t.$set(te);const se={};r&5&&(se.$$scope={dirty:r,ctx:a}),n.$set(se);const ae={};r&5&&(ae.$$scope={dirty:r,ctx:a}),s.$set(ae);const oe={};r&5&&(oe.$$scope={dirty:r,ctx:a}),N.$set(oe);const le={};r&5&&(le.$$scope={dirty:r,ctx:a}),D.$set(le);const ie={};r&5&&(ie.$$scope={dirty:r,ctx:a}),P.$set(ie);const ne={};r&5&&(ne.$$scope={dirty:r,ctx:a}),B.$set(ne);const ce={};r&5&&(ce.$$scope={dirty:r,ctx:a}),R.$set(ce);const re={};r&5&&(re.$$scope={dirty:r,ctx:a}),V.$set(re);const de={};r&5&&(de.$$scope={dirty:r,ctx:a}),A.$set(de);const he={};r&5&&(he.$$scope={dirty:r,ctx:a}),W.$set(he);const ue={};r&5&&(ue.$$scope={dirty:r,ctx:a}),q.$set(ue);const pe={};r&5&&(pe.$$scope={dirty:r,ctx:a}),z.$set(pe)},i(a){Z||(g(e.$$.fragment,a),g(t.$$.fragment,a),g(n.$$.fragment,a),g(s.$$.fragment,a),g(N.$$.fragment,a),g(D.$$.fragment,a),g(P.$$.fragment,a),g(B.$$.fragment,a),g(R.$$.fragment,a),g(V.$$.fragment,a),g(A.$$.fragment,a),g(W.$$.fragment,a),g(q.$$.fragment,a),g(z.$$.fragment,a),Z=!0)},o(a){_(e.$$.fragment,a),_(t.$$.fragment,a),_(n.$$.fragment,a),_(s.$$.fragment,a),_(N.$$.fragment,a),_(D.$$.fragment,a),_(P.$$.fragment,a),_(B.$$.fragment,a),_(R.$$.fragment,a),_(V.$$.fragment,a),_(A.$$.fragment,a),_(W.$$.fragment,a),_(q.$$.fragment,a),_(z.$$.fragment,a),Z=!1},d(a){a&&(d(i),d(o),d(h),d(l),d(F),d(J),d(G),d(K),d(O),d(Q),d(U),d(X),d(Y)),w(e,a),w(t,a),w(n,a),w(s,a),w(N,a),w(D,a),w(P,a),w(B,a),w(R,a),w(V,a),w(A,a),w(W,a),w(q,a),w(z,a)}}}function Ye(c){let e,i;const t=[c[1],me];let o={$$slots:{default:[Xe]},$$scope:{ctx:c}};for(let n=0;n<t.length;n+=1)o=ee(o,t[n]);return e=new ye({props:o}),{c(){m(e.$$.fragment)},l(n){v(e.$$.fragment,n)},m(n,h){b(e,n,h),i=!0},p(n,[h]){const s=h&2?we(t,[h&2&&fe(n[1]),h&0&&fe(me)]):{};h&5&&(s.$$scope={dirty:h,ctx:n}),e.$set(s)},i(n){i||(g(e.$$.fragment,n),i=!0)},o(n){_(e.$$.fragment,n),i=!1},d(n){w(e,n)}}}const me={title:"Card",desc:"Cards are used to group and display content in a way that is easily readable.",published:!0,layout:"components"};function Ze(c,e,i){let t;return be(c,xe,o=>i(0,t=o)),c.$$set=o=>{i(1,e=ee(ee({},e),$e(o)))},e=$e(e),[t,e]}class it extends ge{constructor(e){super(),_e(this,e,Ze,Ye,ve,{})}}export{it as component};
