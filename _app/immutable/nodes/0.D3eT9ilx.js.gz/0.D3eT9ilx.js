import{L as e,_ as n}from"../chunks/0.aEUC3kUh.js";export{e as component,n as universal};
